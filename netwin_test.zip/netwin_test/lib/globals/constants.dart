const String baseUrl = "https://reqres.in/api/";
const String projectName = 'Netwin Test';

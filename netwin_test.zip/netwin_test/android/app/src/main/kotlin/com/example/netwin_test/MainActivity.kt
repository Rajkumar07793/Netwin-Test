package com.example.netwin_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
